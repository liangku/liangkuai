import time
import unittest
from framework.logger import MyLog
from framework.app_engine import OpenApp
from framework.base_page import BasePage
from pageobjects.zhuanlan_page import zl
log = MyLog.get_log()
logger = log.getlog()


class zhuanlan(unittest.TestCase):

        @classmethod
        def setUp(cls):
            app = OpenApp(cls)
            cls.driver = app.open_app()

        @classmethod
        def tearDown(cls):
            cls().driver.quit()
        def test_nologin_dingyue(self):
            '''专栏订阅测试用例(未登录条件)'''
            #进入专栏详情页
            zl.zl_details()
            #点击订阅按钮
            zl.dingyue()
            #断言未登录时跳转到登录页
            Text=self.driver.find_element_by_id('com.gelonghui.glhapp:id/tv_main_title')
            text1=Text.text
            self.assertEqual('登录',text1)
        def test_nologin_like(self):
            '''专栏文章点赞（未登录条件）'''
            #进入专栏文章详情页
            zl.zl_details()
            #点击爱心按钮
            zl.like()
            #断言
            Text = self.driver.find_element_by_id('com.gelonghui.glhapp:id/tv_main_title')
            text1 = Text.text
            self.assertEqual('登录', text1)